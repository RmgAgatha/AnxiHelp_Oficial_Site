document.addEventListener("DOMContentLoaded", () => {
  const downloadBtn = document.querySelector(".download-btn");

  downloadBtn.addEventListener("click", () => {
    alert("¡Gracias por descargar AnxiHelp! 🌟");
  });
});

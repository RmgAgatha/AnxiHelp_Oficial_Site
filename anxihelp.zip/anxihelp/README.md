# AnxiHelp

A Pen created on CodePen.io. Original URL: [https://codepen.io/Elkin-Arag-n/pen/gOVyaBY](https://codepen.io/Elkin-Arag-n/pen/gOVyaBY).


AnxiHelp es una aplicación diseñada para ayudar a las personas a manejar la ansiedad. Ofrece herramientas prácticas como ejercicios de respiración, meditación guiada y recursos educativos sobre la ansiedad. Con una interfaz fácil de usar, la app proporciona apoyo durante las crisis y fomenta el bienestar a largo plazo, ayudando a los usuarios a comprender y controlar mejor su ansiedad.